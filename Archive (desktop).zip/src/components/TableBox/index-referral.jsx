import { InnerList, List, ReferralTable, TableWrapper, Title } from "./style";
import EtheriumIcon from "./../../assets/ethereum-icon.svg";

export default function TableBoxReferral({ title }) {
  return (
    <TableWrapper>
      <Title>{title}</Title>
      <List>
        <InnerList>
          <ReferralTable padding={0}>
            <thead>
              <tr>
                <th>Referal Code:</th>
                <th>Profit:</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>asa1233212ss</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
            </tbody>
          </ReferralTable>
        </InnerList>
      </List>
    </TableWrapper>
  );
}
