import {
  HofTable,
  InnerList,
  List,
  TableWrapper,
  Title,
  Wrapper,
} from "./style";
import EtheriumIcon from "./../../assets/ethereum-icon.svg";

export default function HofTableWrapper({ title }) {
  return (
    <TableWrapper>
      <Title>{title}</Title>
      <List>
        <InnerList>
          <HofTable padding={0}>
            <thead>
              <tr>
                <th>Address:</th>
                <th>Total Revenue:</th>
                <th>Total Profit:</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
              <tr>
                <td>HofTableWrapper</td>

                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.00000460
                </td>
              </tr>
            </tbody>
          </HofTable>
        </InnerList>
      </List>
    </TableWrapper>
  );
}
