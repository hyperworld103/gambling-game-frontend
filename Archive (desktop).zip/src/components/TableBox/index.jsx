import { ExperienceTable, InnerList, List, TableWrapper, Title } from "./style";
import EtheriumIcon from "./../../assets/ethereum-icon.svg";

export default function TableBoxExperience({ title }) {
  return (
    <TableWrapper>
      <Title>{title}</Title>
      <List>
        <InnerList>
          <ExperienceTable padding={0}>
            <thead>
              <tr>
                <th>Round:</th>
                <th>Status:</th>
                <th>Total Bet On Red:</th>
                <th>Total Bet On Blue:</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
              <tr>
                <td>100</td>
                <td>Ongoing</td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
                <td>
                  <img src={EtheriumIcon} /> 0.000460000
                </td>
              </tr>
            </tbody>
          </ExperienceTable>
        </InnerList>
      </List>
    </TableWrapper>
  );
}
