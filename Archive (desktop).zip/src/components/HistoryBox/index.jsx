import {
  Address,
  InnerList,
  Item,
  List,
  Title,
  HistoryBoxWrapper,
} from "./style";
import {
  BettingSectionLine,
  BettingSectionSummary,
  BettingSectionSummaryAltText,
  BettingSectionSummaryIcon,
  BettingSectionSummaryText,
} from "../PlayerBox/style";

export default function HistoryBox({ color, teamName }) {
  return (
    <HistoryBoxWrapper>
      <Title color={color}>The Payment History of {teamName} Team</Title>
      <List>
        <InnerList>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
          <Item>
            <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
            <BettingSectionSummary>
              <BettingSectionLine>
                <BettingSectionSummaryIcon />
                <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
              </BettingSectionLine>
              <BettingSectionSummaryText>
                = 0.0001{" "}
                <BettingSectionSummaryAltText>
                  + fee 0.00021384 (21.384%)
                </BettingSectionSummaryAltText>{" "}
              </BettingSectionSummaryText>
              <BettingSectionSummaryAltText>
                =88.8 % share | status: LOSS
              </BettingSectionSummaryAltText>
            </BettingSectionSummary>
          </Item>
        </InnerList>
      </List>
    </HistoryBoxWrapper>
  );
}
