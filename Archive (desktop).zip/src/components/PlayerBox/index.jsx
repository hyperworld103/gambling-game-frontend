import {
  Address,
  BettingSection,
  BettingSectionIcon,
  BettingSectionInput,
  BettingSectionLine,
  BettingSectionSummary,
  BettingSectionSummaryAltText,
  BettingSectionSummaryIcon,
  BettingSectionSummaryText,
  Desc,
  Flag,
  HeaderTitle,
  QRCode,
  ReceivedText,
  ReceivedValue,
  Submit,
  PlayerBoxWrapper,
  PlayerBoxHeader,
  QrCodeWrapper,
  QrCodeTextWrapper,
} from "./style";
import EtheriumIcon from "../../assets/ethereum-icon.svg";

import QRCodeImage from "../../assets/qr_code.png";
import { useState } from "react";

export default function PlayerBox({ color, teamName }) {
  const [bettingValue, setBettingValue] = useState("");

  const handleChange = (e) => {
    setBettingValue(e.target.value);
  };
  return (
    <PlayerBoxWrapper>
      <Flag color={color} />
      <PlayerBoxHeader>
        <HeaderTitle color={color}>The {teamName} Team Received</HeaderTitle>
        <ReceivedValue>
          <img src={EtheriumIcon} /> 0.54506
        </ReceivedValue>
        <ReceivedText>0.006299499 ETH (incl. unfirmed)</ReceivedText>
      </PlayerBoxHeader>
      <QrCodeWrapper>
        <QRCode>
          <img src={QRCodeImage} alt="qr" />
        </QRCode>
        <QrCodeTextWrapper>
          <Desc>
            If you want to invest to the {teamName} team. Send any amount of
            ethers (minimum: 0.001) this address:
          </Desc>
          <Address>1Mon8DByNfLRhnN1M2wTs6iDhT6K7abS4k</Address>
        </QrCodeTextWrapper>
      </QrCodeWrapper>
      <BettingSection>
        <BettingSectionLine>
          <BettingSectionIcon isActive={bettingValue !== ""} />
          <BettingSectionInput
            type="text"
            name={`${color}ethers`}
            placeholder="0.001 - 10"
            value={bettingValue}
            onChange={handleChange}
          />
          <Submit disabled={bettingValue === ""} />
        </BettingSectionLine>
        {bettingValue !== "" && (
          <BettingSectionSummary>
            <BettingSectionLine>
              <BettingSectionSummaryIcon />
              <BettingSectionSummaryText>0.0001</BettingSectionSummaryText>
            </BettingSectionLine>
            <BettingSectionSummaryText>
              = 0.0001{" "}
              <BettingSectionSummaryAltText>
                + fee 0.00021384 (21.384%)
              </BettingSectionSummaryAltText>{" "}
            </BettingSectionSummaryText>
            <BettingSectionSummaryAltText>
              =88.8 % share | status: LOSS
            </BettingSectionSummaryAltText>
          </BettingSectionSummary>
        )}
      </BettingSection>
    </PlayerBoxWrapper>
  );
}
