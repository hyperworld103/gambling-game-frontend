import {
  BalanceBox,
  BalanceBoxTitle,
  BalanceBoxValue,
  BoxWrapper,
  Button,
  CurrentRoundButton,
  CurrentRoundWrapper,
  EndsInfo,
  EndsTitle,
  EndsWrapper,
  LogoWrapper,
  RowWrapper,
  Text,
  TextArea,
  WebBanner,
  WinningBox,
  WinningBoxInfoBox,
  WinningBoxInfoBoxTitle,
  WinningBoxInfoBoxValue,
  WinningBoxTitle,
  Wrapper,
} from "./style";
import Logo from "./../../assets/logo.svg";
import EtheriumIcon from "./../../assets/ethereum-icon.svg";
import PlayerBox from "../PlayerBox/index";
import HistoryBox from "../HistoryBox";
import Footer from "../Footer/index";
import { PlayersBg, PlayersWrapper } from "../PlayerBox/style";

export default function Home() {
  return (
    <>
      <Wrapper>
        <Text>
          Simple, provably fair ethereum game. No registration required.
        </Text>
        <LogoWrapper>
          <img src={Logo} />
        </LogoWrapper>
        <Button>Connect</Button>
      </Wrapper>
      <WebBanner>Banner comes here</WebBanner>
      <BalanceBox>
        <BalanceBoxTitle>Your Balance:</BalanceBoxTitle>
        <BalanceBoxValue>
          <img src={EtheriumIcon} /> 0.000000460
        </BalanceBoxValue>
      </BalanceBox>
      <RowWrapper>
        <TextArea>
          The law of the nature is simple. The big team (the one with more
          ethers) eats the small one and all its ethers plus the jackpot. At the
          end of the round these ethers are shared by all players who invested
          into the big team.
        </TextArea>
        <CurrentRoundWrapper>
          <CurrentRoundButton>
            Current Round: <span>199</span>
          </CurrentRoundButton>
          <EndsWrapper>
            <EndsTitle>This Rounds Ends In:</EndsTitle>
            <EndsInfo>5H 25M 16S</EndsInfo>
          </EndsWrapper>
        </CurrentRoundWrapper>
      </RowWrapper>
      <WinningBox>
        <WinningBoxTitle>
          <span>Blue</span> is Winning
        </WinningBoxTitle>
        <WinningBoxInfoBox>
          <WinningBoxInfoBoxTitle>Current Fee:</WinningBoxInfoBoxTitle>
          <WinningBoxInfoBoxValue>17.8677%</WinningBoxInfoBoxValue>
        </WinningBoxInfoBox>

        <WinningBoxInfoBox>
          <WinningBoxInfoBoxTitle>This Rounds Jackpot:</WinningBoxInfoBoxTitle>
          <WinningBoxInfoBoxValue>
            <img src={EtheriumIcon} /> 0.00000560
          </WinningBoxInfoBoxValue>
        </WinningBoxInfoBox>
      </WinningBox>
      <BoxWrapper>
        <PlayersWrapper>
          <PlayersBg />
          <PlayerBox color="blue" teamName="Blue" />
          <PlayerBox color="red" teamName="Red" />
        </PlayersWrapper>
        <HistoryBox color="red" teamName="Red" />
        <HistoryBox color="blue" teamName="Blue" />
      </BoxWrapper>
      <Footer />
    </>
  );
}
