import { Wrapper } from "./style";
import { Button } from "../Home/style";

export default function Footer() {
  return (
    <Wrapper>
      Footer <Button>Hall of Fame</Button>
    </Wrapper>
  );
}
