export const breakpoints = {
  tablet: "678px",
  web: "960px",
  wide: "1140px",
};
