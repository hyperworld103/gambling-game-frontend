import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Home from "./components/Home";
import Home3 from "./components/Home/index-3";
import Home4 from "./components/Home/index-4";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/3">
          <Home3 />
        </Route>
        <Route path="/4">
          <Home4 />
        </Route>
        <Route path="/">
          <Home />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
